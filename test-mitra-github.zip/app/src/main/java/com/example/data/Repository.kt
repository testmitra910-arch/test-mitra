package com.example.data

import android.content.Context
import android.provider.Settings
import androidx.room.Room
import com.example.data.local.AppDatabase
import com.example.data.local.LocalActiveTestEntity
import com.example.data.local.LocalProfileEntity
import com.example.data.local.LocalTestAnswerEntity
import com.example.data.remote.SupabaseApiClient
import com.example.model.ActiveSession
import com.example.model.AdminInfo
import com.example.model.ExamType
import com.example.model.NotificationItem
import com.example.model.Profile
import com.example.model.Question
import com.example.model.StudentInfo
import com.example.model.Test
import com.example.model.TestAnswer
import com.example.model.TestAnswerDetail
import com.example.model.TestAttempt
import com.example.model.TestResultSummary
import java.security.MessageDigest
import java.util.UUID

class Repository(private val context: Context) {

    val db: AppDatabase = Room.databaseBuilder(
        context.applicationContext,
        AppDatabase::class.java,
        "test_mitra_local.db"
    ).fallbackToDestructiveMigration().build()

    val apiClient = SupabaseApiClient(context.applicationContext)

    fun getDeviceId(): String {
        return Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: UUID.randomUUID().toString()
    }

    // SHA-256 Secure Password Hash
    fun hashPassword(password: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(password.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    // --- AUTHENTICATION & SINGLE SESSION ---
    suspend fun login(mobileNumber: String, passwordRaw: String): Result<Profile> {
        return try {
            val profile = apiClient.getProfileByMobile(mobileNumber.trim())
                ?: return Result.failure(Exception("આ મોબાઇલ નંબર સાથે એકાઉન્ટ મળ્યું નથી."))

            if (!profile.isActive) {
                return Result.failure(Exception("તમારું એકાઉન્ટ નિષ્ક્રિય (Inactive) છે. સંપર્ક કરો."))
            }

            // Verify password stored in profile metadata or via Auth
            val inputHash = hashPassword(passwordRaw)
            val storedAuthId = profile.authId ?: ""

            // Simple verification check matching auth_id token or hash
            if (storedAuthId.isNotBlank() && storedAuthId != inputHash && storedAuthId != passwordRaw) {
                return Result.failure(Exception("મોબાઇલ નંબર અથવા પાસવર્ડ ખોટો છે."))
            }

            val deviceId = getDeviceId()
            val currentSessionId = UUID.randomUUID().toString()

            // One Device Session Enforcement
            val existingActiveSession = try {
                apiClient.getActiveSessionForUser(profile.id)
            } catch (e: Exception) { null }

            if (existingActiveSession != null && existingActiveSession.deviceId != deviceId) {
                // Invalidate old session and register new session for this device
                apiClient.registerActiveSession(
                    ActiveSession(
                        id = UUID.randomUUID().toString(),
                        userId = profile.id,
                        sessionId = currentSessionId,
                        deviceId = deviceId,
                        deviceName = android.os.Build.MODEL
                    )
                )
            } else {
                apiClient.registerActiveSession(
                    ActiveSession(
                        id = UUID.randomUUID().toString(),
                        userId = profile.id,
                        sessionId = currentSessionId,
                        deviceId = deviceId,
                        deviceName = android.os.Build.MODEL
                    )
                )
            }

            // Save session to Room local storage
            var examTypeId: String? = null
            var isMainAdmin = false

            if (profile.role == "student") {
                val studentInfo = apiClient.getStudentByProfileId(profile.id)
                examTypeId = studentInfo?.examTypeId
            } else if (profile.role == "admin" || profile.role == "main_admin") {
                val adminInfo = apiClient.getAdminByProfileId(profile.id)
                examTypeId = adminInfo?.assignedExamTypeId
                isMainAdmin = adminInfo?.isMainAdmin ?: (profile.role == "main_admin")
            }

            val localProfile = LocalProfileEntity(
                id = profile.id,
                name = profile.name,
                mobileNumber = profile.mobileNumber,
                role = profile.role,
                examTypeId = examTypeId,
                isMainAdmin = isMainAdmin,
                sessionToken = currentSessionId,
                deviceId = deviceId
            )
            db.localDao().saveProfile(localProfile)

            Result.success(profile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getLocalProfile(): LocalProfileEntity? {
        return db.localDao().getProfile()
    }

    suspend fun verifyActiveSession(userId: String): Boolean {
        return try {
            val activeSession = apiClient.getActiveSessionForUser(userId) ?: return true
            val localProfile = getLocalProfile()
            activeSession.deviceId == localProfile?.deviceId
        } catch (e: Exception) {
            true
        }
    }

    suspend fun logout() {
        val profile = getLocalProfile()
        if (profile != null) {
            try {
                apiClient.invalidateActiveSession(profile.id)
            } catch (e: Exception) { /* ignored */ }
        }
        db.localDao().clearProfile()
        db.localDao().clearActiveTest()
    }

    // --- SETUP FIRST MAIN ADMIN ---
    suspend fun setupFirstMainAdmin(name: String, mobileNumber: String, passwordRaw: String): Result<Profile> {
        return try {
            val existing = apiClient.getProfileByMobile(mobileNumber.trim())
            if (existing != null) {
                return Result.failure(Exception("આ મોબાઇલ નંબર પહેલેથી રજિસ્ટર્ડ છે."))
            }

            val profileId = UUID.randomUUID().toString()
            val passwordHash = hashPassword(passwordRaw)

            val profile = Profile(
                id = profileId,
                authId = passwordHash,
                name = name.trim(),
                mobileNumber = mobileNumber.trim(),
                role = "main_admin",
                isActive = true
            )
            val createdProfile = apiClient.createProfile(profile)

            val adminInfo = AdminInfo(
                id = UUID.randomUUID().toString(),
                profileId = profileId,
                assignedExamTypeId = null,
                isMainAdmin = true,
                isActive = true
            )
            apiClient.createAdmin(adminInfo)

            Result.success(createdProfile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- MANAGEMENT FOR ADMINS & STUDENTS ---
    suspend fun createAdminAccount(
        name: String,
        mobileNumber: String,
        passwordRaw: String,
        assignedExamTypeId: String?
    ): Result<Profile> {
        return try {
            val existing = apiClient.getProfileByMobile(mobileNumber.trim())
            if (existing != null) return Result.failure(Exception("આ મોબાઇલ નંબર પહેલેથી રજિસ્ટર્ડ છે."))

            val profileId = UUID.randomUUID().toString()
            val passwordHash = hashPassword(passwordRaw)

            val profile = Profile(
                id = profileId,
                authId = passwordHash,
                name = name.trim(),
                mobileNumber = mobileNumber.trim(),
                role = "admin",
                isActive = true
            )
            val createdProfile = apiClient.createProfile(profile)

            val adminInfo = AdminInfo(
                id = UUID.randomUUID().toString(),
                profileId = profileId,
                assignedExamTypeId = assignedExamTypeId,
                isMainAdmin = false,
                isActive = true
            )
            apiClient.createAdmin(adminInfo)

            Result.success(createdProfile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createStudentAccount(
        name: String,
        mobileNumber: String,
        passwordRaw: String,
        examTypeId: String,
        createdByProfileId: String
    ): Result<Profile> {
        return try {
            val existing = apiClient.getProfileByMobile(mobileNumber.trim())
            if (existing != null) return Result.failure(Exception("આ મોબાઇલ નંબર પહેલેથી રજિસ્ટર્ડ છે."))

            val profileId = UUID.randomUUID().toString()
            val passwordHash = hashPassword(passwordRaw)

            val profile = Profile(
                id = profileId,
                authId = passwordHash,
                name = name.trim(),
                mobileNumber = mobileNumber.trim(),
                role = "student",
                isActive = true
            )
            val createdProfile = apiClient.createProfile(profile)

            val studentInfo = StudentInfo(
                id = UUID.randomUUID().toString(),
                profileId = profileId,
                examTypeId = examTypeId,
                isActive = true,
                createdBy = createdByProfileId
            )
            apiClient.createStudent(studentInfo)

            Result.success(createdProfile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- FETCH DATA METHODS ---
    suspend fun getExamTypes(): List<ExamType> {
        val remote = try { apiClient.getExamTypes() } catch (e: Exception) { emptyList() }
        if (remote.isNotEmpty()) return remote

        // Fallback default 5 Exam Types as required by prompt
        return listOf(
            ExamType("navodaya", "નવોદય", "નવોદય પ્રવેશ પરીક્ષા ટેસ્ટ"),
            ExamType("nmms", "NMMS", "National Means Cum Merit Scholarship Test"),
            ExamType("gyan_setu", "જ્ઞાન સેતુ", "જ્ઞાન સેતુ સ્કોલરશિપ ટેસ્ટ"),
            ExamType("gyan_sadhana", "જ્ઞાન સાધના", "જ્ઞાન સાધના સ્કોલરશિપ ટેસ્ટ"),
            ExamType("tet_1", "TET 1", "શિક્ષક યોગ્યતા કસોટી - ૧ (TET 1)")
        )
    }

    suspend fun getStudents(examTypeId: String?): List<Pair<Profile, StudentInfo>> {
        val studentInfos = apiClient.getStudentsByExamType(examTypeId)
        val result = mutableListOf<Pair<Profile, StudentInfo>>()
        for (info in studentInfos) {
            val profile = apiClient.getProfileById(info.profileId)
            if (profile != null) {
                result.add(Pair(profile, info))
            }
        }
        return result
    }

    suspend fun getAdmins(): List<Pair<Profile, AdminInfo>> {
        val adminInfos = apiClient.getAllAdmins()
        val result = mutableListOf<Pair<Profile, AdminInfo>>()
        for (info in adminInfos) {
            val profile = apiClient.getProfileById(info.profileId)
            if (profile != null) {
                result.add(Pair(profile, info))
            }
        }
        return result
    }

    suspend fun updateProfileStatus(profileId: String, isActive: Boolean) {
        apiClient.updateProfileStatus(profileId, isActive)
    }

    suspend fun deleteProfile(profileId: String) {
        apiClient.deleteProfile(profileId)
    }

    // --- TESTS & QUESTIONS ---
    suspend fun getTests(examTypeId: String?, statusFilter: String? = null): List<Test> {
        return apiClient.getTests(examTypeId, statusFilter)
    }

    suspend fun createTest(test: Test): Test {
        return apiClient.createTest(test)
    }

    suspend fun updateTestStatus(testId: String, status: String) {
        apiClient.updateTestStatus(testId, status)
    }

    suspend fun deleteTest(testId: String) {
        apiClient.deleteTest(testId)
    }

    suspend fun getQuestions(testId: String): List<Question> {
        return apiClient.getQuestionsByTestId(testId)
    }

    suspend fun createQuestion(question: Question): Question {
        return apiClient.createQuestion(question)
    }

    suspend fun deleteQuestion(questionId: String) {
        apiClient.deleteQuestion(questionId)
    }

    // --- NOTIFICATIONS ---
    suspend fun getNotifications(examTypeId: String?): List<NotificationItem> {
        return apiClient.getNotifications(examTypeId)
    }

    suspend fun createNotification(notification: NotificationItem): NotificationItem {
        return apiClient.createNotification(notification)
    }

    suspend fun deleteNotification(notificationId: String) {
        apiClient.deleteNotification(notificationId)
    }

    // --- TEST EXECUTION & SCORING ---
    suspend fun startTestAttempt(test: Test, studentId: String): Pair<TestAttempt, LocalActiveTestEntity> {
        val attemptId = UUID.randomUUID().toString()
        val startTimeMillis = System.currentTimeMillis()
        val durationMillis = test.durationMinutes * 60 * 1000L
        val targetEndTimeMillis = startTimeMillis + durationMillis

        val attempt = TestAttempt(
            id = attemptId,
            testId = test.id,
            studentId = studentId,
            startedAt = java.time.Instant.now().toString(),
            status = "in_progress"
        )

        val createdAttempt = try {
            apiClient.createTestAttempt(attempt)
        } catch (e: Exception) { attempt }

        val activeTestEntity = LocalActiveTestEntity(
            attemptId = attemptId,
            testId = test.id,
            testName = test.name,
            durationMinutes = test.durationMinutes,
            startTimeMillis = startTimeMillis,
            targetEndTimeMillis = targetEndTimeMillis,
            studentId = studentId,
            totalQuestions = 0
        )
        db.localDao().saveActiveTest(activeTestEntity)

        return Pair(createdAttempt, activeTestEntity)
    }

    suspend fun saveAnswerLocally(attemptId: String, questionId: String, selectedAnswer: String?) {
        val entity = LocalTestAnswerEntity(
            id = "${attemptId}_$questionId",
            attemptId = attemptId,
            questionId = questionId,
            selectedAnswer = selectedAnswer
        )
        db.localDao().saveAnswer(entity)
    }

    suspend fun submitTestAttempt(
        attemptId: String,
        test: Test,
        questions: List<Question>,
        studentId: String
    ): TestResultSummary {
        val localAnswers = db.localDao().getAnswersForAttempt(attemptId)
        val answerMap = localAnswers.associate { it.questionId to it.selectedAnswer }

        var correctCount = 0
        var wrongCount = 0
        var unansweredCount = 0
        var totalScore = 0
        val totalMarks = questions.sumOf { it.marks }

        val remoteAnswers = mutableListOf<TestAnswer>()
        val answerDetails = mutableListOf<TestAnswerDetail>()

        for (q in questions) {
            val sel = answerMap[q.id]
            val isCorrect = sel != null && sel.equals(q.correctAnswer, ignoreCase = true)
            val marksObtained = if (isCorrect) q.marks else 0

            if (sel.isNull_or_blank()) {
                unansweredCount++
            } else if (isCorrect) {
                correctCount++
                totalScore += q.marks
            } else {
                wrongCount++
            }

            val testAns = TestAnswer(
                id = UUID.randomUUID().toString(),
                attemptId = attemptId,
                questionId = q.id,
                selectedAnswer = sel ?: "UNANSWERED",
                isCorrect = isCorrect,
                marksObtained = marksObtained
            )
            remoteAnswers.add(testAns)

            answerDetails.add(
                TestAnswerDetail(
                    question = q,
                    selectedAnswer = sel,
                    correctAnswer = q.correctAnswer,
                    isCorrect = isCorrect
                )
            )
        }

        val activeTest = db.localDao().getActiveTest()
        val timeTakenSecs = if (activeTest != null) {
            ((System.currentTimeMillis() - activeTest.startTimeMillis) / 1000).toInt().coerceAtLeast(0)
        } else {
            0
        }

        val percentage = if (totalMarks > 0) (totalScore.toFloat() / totalMarks.toFloat()) * 100f else 0f

        val updatedAttempt = TestAttempt(
            id = attemptId,
            testId = test.id,
            studentId = studentId,
            submittedAt = java.time.Instant.now().toString(),
            timeTakenSeconds = timeTakenSecs,
            score = totalScore,
            totalMarks = totalMarks,
            status = "completed"
        )

        try {
            apiClient.updateTestAttempt(updatedAttempt)
            apiClient.createTestAnswers(remoteAnswers)
        } catch (e: Exception) { /* Sync error, local result generated */ }

        db.localDao().markTestSubmitted(attemptId)

        val profile = getLocalProfile()
        return TestResultSummary(
            attempt = updatedAttempt,
            testName = test.name,
            studentName = profile?.name ?: "વિદ્યાર્થી",
            totalQuestions = questions.size,
            correctCount = correctCount,
            wrongCount = wrongCount,
            unansweredCount = unansweredCount,
            score = totalScore,
            totalMarks = totalMarks,
            percentage = percentage,
            timeTakenSeconds = timeTakenSecs,
            answers = answerDetails
        )
    }

    suspend fun getStudentResults(studentId: String): List<TestResultSummary> {
        val attempts = try { apiClient.getTestAttemptsByStudent(studentId) } catch (e: Exception) { emptyList() }
        val summaries = mutableListOf<TestResultSummary>()

        for (att in attempts) {
            val answers = try { apiClient.getTestAnswersForAttempt(att.id) } catch (e: Exception) { emptyList() }
            val questions = try { apiClient.getQuestionsByTestId(att.testId) } catch (e: Exception) { emptyList<com.example.model.Question>() }
            val qMap = questions.associateBy { it.id }

            var correctCount = 0
            var wrongCount = 0
            var unansweredCount = 0

            val details = answers.mapNotNull { ans ->
                val q = qMap[ans.questionId] ?: return@mapNotNull null
                val sel = ans.selectedAnswer
                if (sel == "UNANSWERED" || sel.isNull_or_blank()) unansweredCount++
                else if (ans.isCorrect) correctCount++
                else wrongCount++

                TestAnswerDetail(
                    question = q,
                    selectedAnswer = if (sel == "UNANSWERED") null else sel,
                    correctAnswer = q.correctAnswer,
                    isCorrect = ans.isCorrect
                )
            }

            val percentage = if (att.totalMarks > 0) (att.score.toFloat() / att.totalMarks.toFloat()) * 100f else 0f
            summaries.add(
                TestResultSummary(
                    attempt = att,
                    testName = "Test",
                    studentName = "",
                    totalQuestions = questions.size,
                    correctCount = correctCount,
                    wrongCount = wrongCount,
                    unansweredCount = unansweredCount,
                    score = att.score,
                    totalMarks = att.totalMarks,
                    percentage = percentage,
                    timeTakenSeconds = att.timeTakenSeconds,
                    answers = details
                )
            )
        }
        return summaries
    }

    suspend fun getAllResults(): List<TestResultSummary> {
        val attempts = try { apiClient.getAllTestAttempts() } catch (e: Exception) { emptyList() }
        val summaries = mutableListOf<TestResultSummary>()

        for (att in attempts) {
            val studentProfile = try {
                val studentInfos = apiClient.getStudentsByExamType(null)
                val info = studentInfos.firstOrNull { it.id == att.studentId }
                if (info != null) apiClient.getProfileById(info.profileId) else null
            } catch (e: Exception) { null }

            val percentage = if (att.totalMarks > 0) (att.score.toFloat() / att.totalMarks.toFloat()) * 100f else 0f

            summaries.add(
                TestResultSummary(
                    attempt = att,
                    testName = "Test",
                    studentName = studentProfile?.name ?: "વિદ્યાર્થી",
                    totalQuestions = 0,
                    correctCount = 0,
                    wrongCount = 0,
                    unansweredCount = 0,
                    score = att.score,
                    totalMarks = att.totalMarks,
                    percentage = percentage,
                    timeTakenSeconds = att.timeTakenSeconds
                )
            )
        }
        return summaries
    }

    private fun String?.isNull_or_blank(): Boolean {
        return this == null || this.trim().isEmpty()
    }
}
