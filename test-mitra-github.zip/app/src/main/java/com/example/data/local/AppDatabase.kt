package com.example.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase

@Dao
interface LocalDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProfile(profile: LocalProfileEntity)

    @Query("SELECT * FROM local_profile LIMIT 1")
    suspend fun getProfile(): LocalProfileEntity?

    @Query("DELETE FROM local_profile")
    suspend fun clearProfile()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveActiveTest(test: LocalActiveTestEntity)

    @Query("SELECT * FROM local_active_test WHERE isSubmitted = 0 LIMIT 1")
    suspend fun getActiveTest(): LocalActiveTestEntity?

    @Query("UPDATE local_active_test SET isSubmitted = 1 WHERE attemptId = :attemptId")
    suspend fun markTestSubmitted(attemptId: String)

    @Query("DELETE FROM local_active_test")
    suspend fun clearActiveTest()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAnswer(answer: LocalTestAnswerEntity)

    @Query("SELECT * FROM local_test_answer WHERE attemptId = :attemptId")
    suspend fun getAnswersForAttempt(attemptId: String): List<LocalTestAnswerEntity>

    @Query("DELETE FROM local_test_answer WHERE attemptId = :attemptId")
    suspend fun clearAnswersForAttempt(attemptId: String)
}

@Database(
    entities = [LocalProfileEntity::class, LocalActiveTestEntity::class, LocalTestAnswerEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun localDao(): LocalDao
}
