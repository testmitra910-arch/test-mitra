package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.ExamType
import com.example.model.Profile
import com.example.model.StudentInfo
import com.example.ui.theme.ColorNavodaya
import com.example.ui.theme.PrimaryBlue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminStudentMgmtScreen(
    students: List<Pair<Profile, StudentInfo>>,
    examTypes: List<ExamType>,
    adminProfileId: String,
    isLoading: Boolean,
    onBack: () -> Unit,
    onAddStudent: (name: String, mobile: String, pass: String, examTypeId: String, creatorId: String) -> Unit,
    onToggleActive: (profileId: String, currentActive: Boolean) -> Unit,
    onDeleteStudent: (profileId: String) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("વિદ્યાર્થીઓ મેનેજમેન્ટ", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryBlue)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = ColorNavodaya,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_student_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Student")
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF8FAFC))
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    color = PrimaryBlue,
                    modifier = Modifier.align(Alignment.Center)
                )
            } else if (students.isEmpty()) {
                // Strict Empty State per prompt requirement
                Column(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.PersonOff,
                        contentDescription = null,
                        modifier = Modifier.padding(16.dp),
                        tint = Color.Gray
                    )
                    Text(
                        text = "હાલમાં કોઈ વિદ્યાર્થી ઉપલબ્ધ નથી.",
                        fontSize = 16.sp,
                        color = Color.Gray,
                        fontWeight = FontWeight.Medium
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(students) { (profile, info) ->
                        val examName = examTypes.firstOrNull { it.id == info.examTypeId }?.name ?: info.examTypeId
                        StudentCardItem(
                            profile = profile,
                            examName = examName,
                            onToggleActive = { onToggleActive(profile.id, profile.isActive) },
                            onDelete = { onDeleteStudent(profile.id) }
                        )
                    }
                }
            }
        }

        if (showAddDialog) {
            AddStudentDialog(
                examTypes = examTypes,
                onDismiss = { showAddDialog = false },
                onSubmit = { name, mobile, pass, examTypeId ->
                    onAddStudent(name, mobile, pass, examTypeId, adminProfileId)
                    showAddDialog = false
                }
            )
        }
    }
}

@Composable
private fun StudentCardItem(
    profile: Profile,
    examName: String,
    onToggleActive: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = profile.name,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.DarkGray
                )
                Text(
                    text = "📱 ${profile.mobileNumber}",
                    fontSize = 14.sp,
                    color = Color.Gray
                )
                Text(
                    text = "📚 $examName",
                    fontSize = 13.sp,
                    color = PrimaryBlue,
                    fontWeight = FontWeight.Medium
                )
            }

            Row {
                IconButton(onClick = onToggleActive) {
                    Text(
                        text = if (profile.isActive) "Active" else "Inactive",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (profile.isActive) Color(0xFF2E7D32) else Color(0xFFC62828)
                    )
                }

                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFC62828))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddStudentDialog(
    examTypes: List<ExamType>,
    onDismiss: () -> Unit,
    onSubmit: (name: String, mobile: String, pass: String, examTypeId: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var selectedExamTypeId by remember { mutableStateOf(examTypes.firstOrNull()?.id ?: "navodaya") }
    var expanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("વિદ્યાર્થી ઉમેરો (Add Student)", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = PrimaryBlue)

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("વિદ્યાર્થીનું નામ") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("add_student_name_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = mobile,
                    onValueChange = { mobile = it.take(10) },
                    label = { Text("મોબાઇલ નંબર") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("add_student_mobile_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("પાસવર્ડ") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("add_student_pass_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val currentLabel = examTypes.firstOrNull { it.id == selectedExamTypeId }?.name ?: selectedExamTypeId
                    OutlinedTextField(
                        value = currentLabel,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("પરીક્ષાનો પ્રકાર") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )

                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        examTypes.forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type.name) },
                                onClick = {
                                    selectedExamTypeId = type.id
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        if (name.isNotBlank() && mobile.isNotBlank() && password.isNotBlank()) {
                            onSubmit(name, mobile, password, selectedExamTypeId)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_student_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("SAVE STUDENT", fontWeight = FontWeight.Bold)
                }

                TextButton(onClick = onDismiss) { Text("રદ કરો", color = Color.Gray) }
            }
        }
    }
}
