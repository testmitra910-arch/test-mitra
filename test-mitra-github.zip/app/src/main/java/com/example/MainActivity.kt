package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.LocalProfileEntity
import com.example.model.ExamType
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AdminExamTypesScreen
import com.example.ui.screens.AdminStudentMgmtScreen
import com.example.ui.screens.AdminTestsMgmtScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.SetupAdminDialog
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.StudentDashboardScreen
import com.example.ui.screens.SupabaseSettingsDialog
import com.example.ui.theme.TestMitraTheme
import com.example.viewmodel.AdminViewModel
import com.example.viewmodel.AuthState
import com.example.viewmodel.AuthViewModel
import com.example.viewmodel.StudentViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TestMitraTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    TestMitraApp()
                }
            }
        }
    }
}

@Composable
fun TestMitraApp(
    authViewModel: AuthViewModel = viewModel(),
    adminViewModel: AdminViewModel = viewModel(),
    studentViewModel: StudentViewModel = viewModel()
) {
    var showSplash by remember { mutableStateOf(true) }
    var currentAdminScreen by remember { mutableStateOf("DASHBOARD") }
    var selectedExamTypeForTests by remember { mutableStateOf<ExamType?>(null) }
    var currentStudentScreen by remember { mutableStateOf("STUDENT_DASHBOARD") }
    var showSupabaseConfigDialog by remember { mutableStateOf(false) }
    var showSetupAdminDialog by remember { mutableStateOf(false) }

    val authState by authViewModel.authState.collectAsState()

    if (showSplash) {
        SplashScreen(
            onSplashComplete = { showSplash = false }
        )
        return
    }

    if (showSupabaseConfigDialog) {
        SupabaseSettingsDialog(
            onDismiss = { showSupabaseConfigDialog = false },
            onSave = { url, key ->
                authViewModel.saveSupabaseConfig(url, key)
                showSupabaseConfigDialog = false
            }
        )
    }

    if (showSetupAdminDialog) {
        SetupAdminDialog(
            onDismiss = { showSetupAdminDialog = false },
            onSubmit = { name, mobile, pass ->
                authViewModel.setupFirstMainAdmin(name, mobile, pass)
                showSetupAdminDialog = false
            }
        )
    }

    when (val state = authState) {
        is AuthState.Initial, is AuthState.Loading -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        is AuthState.Unauthenticated, is AuthState.Error -> {
            val errorMsg = (state as? AuthState.Error)?.message
            LoginScreen(
                onLoginSubmit = { mobile, pass -> authViewModel.login(mobile, pass) },
                onSetupFirstAdminClick = { showSetupAdminDialog = true },
                onOpenSettingsClick = { showSupabaseConfigDialog = true },
                isLoading = false,
                errorMessage = errorMsg
            )
        }
        is AuthState.Authenticated -> {
            val profile = state.profile
            if (profile.role == "student") {
                StudentFlow(
                    studentProfile = profile,
                    currentScreen = currentStudentScreen,
                    onNavigate = { currentStudentScreen = it },
                    onLogout = { authViewModel.logout() },
                    studentViewModel = studentViewModel
                )
            } else {
                AdminFlow(
                    adminProfile = profile,
                    currentScreen = currentAdminScreen,
                    selectedExamType = selectedExamTypeForTests,
                    onSelectExamType = { selectedExamTypeForTests = it },
                    onNavigate = { currentAdminScreen = it },
                    onLogout = { authViewModel.logout() },
                    onOpenSettings = { showSupabaseConfigDialog = true },
                    adminViewModel = adminViewModel
                )
            }
        }
    }
}

@Composable
fun StudentFlow(
    studentProfile: LocalProfileEntity,
    currentScreen: String,
    onNavigate: (String) -> Unit,
    onLogout: () -> Unit,
    studentViewModel: StudentViewModel
) {
    val examTypeName = studentProfile.examTypeId ?: "Exam"

    when (currentScreen) {
        "STUDENT_DASHBOARD" -> {
            StudentDashboardScreen(
                studentProfile = studentProfile,
                examTypeName = examTypeName,
                onNavMyTests = { onNavigate("MY_TESTS") },
                onNavNotifications = { onNavigate("STUDENT_NOTIFICATIONS") },
                onNavResults = { onNavigate("STUDENT_RESULTS") },
                onNavProfile = { onNavigate("STUDENT_PROFILE") },
                onLogout = onLogout
            )
        }
        else -> {
            StudentDashboardScreen(
                studentProfile = studentProfile,
                examTypeName = examTypeName,
                onNavMyTests = { onNavigate("MY_TESTS") },
                onNavNotifications = { onNavigate("STUDENT_NOTIFICATIONS") },
                onNavResults = { onNavigate("STUDENT_RESULTS") },
                onNavProfile = { onNavigate("STUDENT_PROFILE") },
                onLogout = onLogout
            )
        }
    }
}

@Composable
fun AdminFlow(
    adminProfile: LocalProfileEntity,
    currentScreen: String,
    selectedExamType: ExamType?,
    onSelectExamType: (ExamType?) -> Unit,
    onNavigate: (String) -> Unit,
    onLogout: () -> Unit,
    onOpenSettings: () -> Unit,
    adminViewModel: AdminViewModel
) {
    val students by adminViewModel.students.collectAsState()
    val admins by adminViewModel.admins.collectAsState()
    val examTypes by adminViewModel.examTypes.collectAsState()
    val tests by adminViewModel.tests.collectAsState()
    val notifications by adminViewModel.notifications.collectAsState()
    val isLoading by adminViewModel.isLoading.collectAsState()

    LaunchedEffect(Unit) {
        adminViewModel.loadExamTypes()
        adminViewModel.loadStudents(adminProfile.examTypeId)
        adminViewModel.loadTests(adminProfile.examTypeId)
        adminViewModel.loadNotifications(adminProfile.examTypeId)
        if (adminProfile.isMainAdmin) {
            adminViewModel.loadAdmins()
            adminViewModel.loadResults()
        }
    }

    when (currentScreen) {
        "DASHBOARD" -> {
            AdminDashboardScreen(
                adminProfile = adminProfile,
                totalStudents = students.size,
                totalTests = tests.size,
                totalNotifications = notifications.size,
                totalAdmins = admins.size,
                onNavStudents = { onNavigate("STUDENT_MGMT") },
                onNavExamTypes = { onNavigate("EXAM_TYPES") },
                onNavNotifications = { onNavigate("NOTIFICATIONS_MGMT") },
                onNavAdminMgmt = { onNavigate("ADMIN_MGMT") },
                onNavResults = { onNavigate("RESULTS_MGMT") },
                onLogout = onLogout,
                onOpenSettings = onOpenSettings
            )
        }
        "STUDENT_MGMT" -> {
            AdminStudentMgmtScreen(
                students = students,
                examTypes = examTypes,
                adminProfileId = adminProfile.id,
                isLoading = isLoading,
                onBack = { onNavigate("DASHBOARD") },
                onAddStudent = { name, mobile, pass, examTypeId, creatorId ->
                    adminViewModel.addStudent(name, mobile, pass, examTypeId, creatorId)
                },
                onToggleActive = { pId, active ->
                    adminViewModel.toggleProfileActive(pId, active, adminProfile.examTypeId)
                },
                onDeleteStudent = { pId ->
                    adminViewModel.deleteProfile(pId, adminProfile.examTypeId)
                }
            )
        }
        "EXAM_TYPES" -> {
            AdminExamTypesScreen(
                examTypes = examTypes,
                allTests = tests,
                onBack = { onNavigate("DASHBOARD") },
                onSelectExamType = { examType ->
                    onSelectExamType(examType)
                    adminViewModel.loadTests(examType.id)
                    onNavigate("TEST_MGMT")
                }
            )
        }
        "TEST_MGMT" -> {
            val exam = selectedExamType ?: examTypes.firstOrNull() ?: ExamType("navodaya", "નવોદય")
            AdminTestsMgmtScreen(
                examType = exam,
                tests = tests,
                isLoading = isLoading,
                adminProfileId = adminProfile.id,
                onBack = { onNavigate("DASHBOARD") },
                onAddTest = { name, desc, duration, passing ->
                    adminViewModel.addTest(name, desc, exam.id, duration, passing, adminProfile.id)
                },
                onTogglePublish = { testId, status ->
                    adminViewModel.toggleTestStatus(testId, status, adminProfile.examTypeId)
                },
                onDeleteTest = { testId ->
                    adminViewModel.deleteTest(testId, adminProfile.examTypeId)
                },
                onManageQuestions = { test ->
                    adminViewModel.loadQuestions(test.id)
                }
            )
        }
        else -> {
            AdminDashboardScreen(
                adminProfile = adminProfile,
                totalStudents = students.size,
                totalTests = tests.size,
                totalNotifications = notifications.size,
                totalAdmins = admins.size,
                onNavStudents = { onNavigate("STUDENT_MGMT") },
                onNavExamTypes = { onNavigate("EXAM_TYPES") },
                onNavNotifications = { onNavigate("NOTIFICATIONS_MGMT") },
                onNavAdminMgmt = { onNavigate("ADMIN_MGMT") },
                onNavResults = { onNavigate("RESULTS_MGMT") },
                onLogout = onLogout,
                onOpenSettings = onOpenSettings
            )
        }
    }
}
